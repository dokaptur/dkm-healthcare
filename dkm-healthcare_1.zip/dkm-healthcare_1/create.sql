CREATE SCHEMA "dkm-healthcare";

CREATE SEQUENCE "dkm-healthcare".seq_id_zabieg START WITH 1 INCREMENT BY 1;

CREATE SEQUENCE "dkm-healthcare".seq_nr_recepty START WITH 1 INCREMENT BY 1;

CREATE SEQUENCE "dkm-healthcare".seq_nr_skier START WITH 1 INCREMENT BY 1;


CREATE TABLE "dkm-healthcare".osoby ( 
	pesel                char(11)  NOT NULL,
	haslo                char(32)  NOT NULL,
	n                    integer DEFAULT 1 NOT NULL,
	n_iteracja           char(32)  ,
	imie                 varchar(20)  NOT NULL,
	nazwisko             varchar(50)  NOT NULL,
	data_urodzenia       date  NOT NULL,
	adres                text  ,
	aptekarz             bool  ,
	admin                bool DEFAULT 'false' NOT NULL,
	email                text  ,
	CONSTRAINT pk_osoby PRIMARY KEY ( pesel )
 );

CREATE TABLE "dkm-healthcare".placowki ( 
	id_placowka          numeric  NOT NULL,
	typ                  text  NOT NULL,
	nazwa                text  NOT NULL,
	adres                text  NOT NULL,
	miasto               text  NOT NULL,
	nr_tel               numeric  NOT NULL,
	CONSTRAINT pk_placowki PRIMARY KEY ( id_placowka )
 );

ALTER TABLE "dkm-healthcare".placowki ADD CONSTRAINT typ_check CHECK ( typ in ('poradnia', 'szpital', 'przychodnia') );

CREATE TABLE "dkm-healthcare".specjalizacje ( 
	nazwa                text  NOT NULL,
	id_spec              integer  NOT NULL,
	CONSTRAINT pk_specjalizacje PRIMARY KEY ( id_spec )
 );

CREATE TABLE "dkm-healthcare".zabiegi ( 
	id_zabieg            integer DEFAULT nextval('"dkm-healthcare".seq_id_zabieg') NOT NULL,
	nazwa                text  NOT NULL,
	CONSTRAINT pk_zabiegi PRIMARY KEY ( id_zabieg )
 );

CREATE TABLE "dkm-healthcare".lekarze ( 
	id_lekarz            char(11)  NOT NULL,
	prawa                bool DEFAULT 'true' NOT NULL,
	CONSTRAINT pk_lekarze PRIMARY KEY ( id_lekarz ),
	CONSTRAINT fk_lekarze FOREIGN KEY ( id_lekarz ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE
 );

CREATE TABLE "dkm-healthcare".osoby_info ( 
	pesel                char(11)  NOT NULL,
	lekarz_rodzinny      char(11)  ,
	historia_modyfikacja date DEFAULT current_date NOT NULL,
	info                 text  ,
	CONSTRAINT pk_osoby_info PRIMARY KEY ( pesel ),
	CONSTRAINT fk_osoby_info FOREIGN KEY ( pesel ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk1_osoby_info FOREIGN KEY ( lekarz_rodzinny ) REFERENCES "dkm-healthcare".lekarze( id_lekarz ) ON DELETE SET NULL ON UPDATE CASCADE
 );
 
 ALTER TABLE "dkm-healthcare".osoby_info ADD CONSTRAINT ck_1 CHECK ( pesel != lekarz_rodzinny );

 
 CREATE TABLE "dkm-healthcare".osoby_alergie ( 
	pesel                char(11)  NOT NULL,
	alergia              text  ,
	CONSTRAINT pk_osoby_alergie PRIMARY KEY ( pesel, alergia ),
	CONSTRAINT fk_osoby_alergie FOREIGN KEY ( pesel ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE
 );
 
 CREATE TABLE "dkm-healthcare".osoby_leki ( 
	pesel                char(11)  NOT NULL,
	lek                  text  ,
	CONSTRAINT pk_osoby_leki PRIMARY KEY ( pesel, lek ),
	CONSTRAINT fk_osoby_leki FOREIGN KEY ( pesel ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE
 );



--CREATE INDEX idx_osoby_info ON "dkm-healthcare".osoby ( lekarz_rodzinny );

CREATE TABLE "dkm-healthcare".pacjenci_specjalisci ( 
	pesel                char(11)  NOT NULL,
	id_lekarz            char(11)  NOT NULL,
	CONSTRAINT idx_pacjenci_specjalisci PRIMARY KEY ( pesel, id_lekarz ),
	--CONSTRAINT pk_pacjenci_specjalisci UNIQUE ( pesel ) ,
	--CONSTRAINT idx_pacjenci_specjalisci_0 UNIQUE ( id_lekarz ) ,
	CONSTRAINT fk_pacjenci_specjalisci FOREIGN KEY ( id_lekarz ) REFERENCES "dkm-healthcare".lekarze( id_lekarz ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_pacjenci_specjalisci_0 FOREIGN KEY ( pesel ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE
 );

ALTER TABLE "dkm-healthcare".pacjenci_specjalisci ADD CONSTRAINT ck_0 CHECK ( pesel != id_lekarz );

CREATE TABLE "dkm-healthcare".placowki_zabiegi ( 
	id_placowka          numeric  NOT NULL,
	id_zabieg            integer  NOT NULL,
	CONSTRAINT idx_placowki_zabiegi PRIMARY KEY ( id_placowka, id_zabieg ),
	CONSTRAINT fk_placowki_zabiegi FOREIGN KEY ( id_placowka ) REFERENCES "dkm-healthcare".placowki( id_placowka ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_placowki_zabiegi_0 FOREIGN KEY ( id_zabieg ) REFERENCES "dkm-healthcare".zabiegi( id_zabieg ) ON DELETE CASCADE ON UPDATE CASCADE
 );

CREATE INDEX idx_placowki_zabiegi_0 ON "dkm-healthcare".placowki_zabiegi ( id_placowka );

CREATE INDEX idx_placowki_zabiegi_1 ON "dkm-healthcare".placowki_zabiegi ( id_zabieg );

CREATE TABLE "dkm-healthcare".recepty ( 
	numer                numeric DEFAULT nextval('"dkm-healthcare".seq_nr_recepty') NOT NULL,
	pesel                char(11)  NOT NULL,
	id_lekarz            char(11)  ,
	zrealizowana_przez   char(11)  ,
	lek                  text  NOT NULL,
	data_waznosci        date DEFAULT current_date + interval '3 month' ,
	zrealizowana         bool DEFAULT 'false' NOT NULL,
	CONSTRAINT pk_recepty PRIMARY KEY ( numer ),
	CONSTRAINT fk_recepty FOREIGN KEY ( pesel ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_recepty_0 FOREIGN KEY ( id_lekarz ) REFERENCES "dkm-healthcare".lekarze( id_lekarz ) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT fk_recepty_1 FOREIGN KEY ( zrealizowana_przez ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE SET NULL ON UPDATE CASCADE
 );

CREATE INDEX idx_recepty ON "dkm-healthcare".recepty ( id_lekarz );

CREATE INDEX idx_recepty_0 ON "dkm-healthcare".recepty ( pesel );

CREATE INDEX idx_recepty_1 ON "dkm-healthcare".recepty ( zrealizowana_przez );

CREATE TABLE "dkm-healthcare".skierowania ( 
	numer                numeric DEFAULT nextval('"dkm-healthcare".seq_nr_skier') NOT NULL,
	pesel                char(11)  NOT NULL,
	id_lekarz            char(11)  ,
	id_zabieg            integer  NOT NULL,
	zrealizowany         bool DEFAULT 'false' NOT NULL,
	CONSTRAINT pk_skierowania PRIMARY KEY ( numer ),
	CONSTRAINT fk_skierowania_1 FOREIGN KEY ( id_zabieg ) REFERENCES "dkm-healthcare".zabiegi( id_zabieg ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_skierowania FOREIGN KEY ( pesel ) REFERENCES "dkm-healthcare".osoby( pesel ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_skierowania_0 FOREIGN KEY ( id_lekarz ) REFERENCES "dkm-healthcare".lekarze( id_lekarz ) ON DELETE SET NULL ON UPDATE CASCADE
 );

CREATE INDEX idx_skierowania ON "dkm-healthcare".skierowania ( pesel );

CREATE INDEX idx_skierowania_0 ON "dkm-healthcare".skierowania ( id_lekarz );

CREATE INDEX idx_skierowania_1 ON "dkm-healthcare".skierowania ( id_zabieg );

CREATE TABLE "dkm-healthcare".lekarze_placowki ( 
	id_lekarz            char(11)  NOT NULL,
	id_placowka          numeric  NOT NULL,
	CONSTRAINT idx_lekarze_placowki PRIMARY KEY ( id_lekarz, id_placowka ),
	--CONSTRAINT pk_lekarze_placowki UNIQUE ( id_placowka ) ,
	CONSTRAINT fk_lekarze_placowki FOREIGN KEY ( id_placowka ) REFERENCES "dkm-healthcare".placowki( id_placowka ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_lekarze_placowki_0 FOREIGN KEY ( id_lekarz ) REFERENCES "dkm-healthcare".lekarze( id_lekarz ) ON DELETE CASCADE ON UPDATE CASCADE
 );

CREATE INDEX idx_lekarze_placowki_0 ON "dkm-healthcare".lekarze_placowki ( id_lekarz );

CREATE TABLE "dkm-healthcare".lekarze_specjalizacje ( 
	id_lekarz            char(11)  NOT NULL,
	id_spec              integer  NOT NULL,
	CONSTRAINT idx_lekarze_specjalizacje PRIMARY KEY ( id_lekarz, id_spec ),
	CONSTRAINT fk_lekarze_specjalizacje_0 FOREIGN KEY ( id_spec ) REFERENCES "dkm-healthcare".specjalizacje( id_spec ) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_lekarze_specjalizacje FOREIGN KEY ( id_lekarz ) REFERENCES "dkm-healthcare".lekarze( id_lekarz ) ON DELETE CASCADE ON UPDATE CASCADE
 );

CREATE INDEX idx_lekarze_specjalizacje_0 ON "dkm-healthcare".lekarze_specjalizacje ( id_lekarz );

CREATE INDEX idx_lekarze_specjalizacje_1 ON "dkm-healthcare".lekarze_specjalizacje ( id_spec );

CREATE VIEW "dkm-healthcare".historia_powiadomienia AS SELECT imie,nazwisko,email FROM "dkm-healthcare".osoby natural join "dkm-healthcare".osoby_info
where historia_modyfikacja = current_date order by pesel;

CREATE VIEW "dkm-healthcare".recepty_powiadomienia_5 AS SELECT imie,nazwisko,email, numer as "recepta" FROM "dkm-healthcare".osoby natural join "dkm-healthcare".recepty 
where zrealizowana = false and email is not null and 
extract(day from age(data_waznosci, current_date))=5  order by pesel;

CREATE VIEW "dkm-healthcare".recepty_powiadomienia_dzis AS SELECT imie,nazwisko,email, numer as "recepta" FROM "dkm-healthcare".osoby natural join "dkm-healthcare".recepty 
where zrealizowana = false and email is not null and 
data_waznosci=current_date order by pesel;

CREATE VIEW "dkm-healthcare".zabiegi_info AS SELECT z.nazwa, id_zabieg ,adres, miasto, nr_tel  from "dkm-healthcare".zabiegi z natural join "dkm-healthcare".placowki_zabiegi
join "dkm-healthcare".placowki p using (id_placowka) order by id_zabieg;



create or replace function add_osoba_info() returns trigger as $$
begin
    insert into "dkm-healthcare".osoby_info(pesel) values (new.pesel);
    return new;
end;
$$ language plpgsql;;

create or replace function change_pesel_check() returns trigger as $$
begin
    new.pesel=old.pesel;
    return new;
end;
$$ language plpgsql;;

create or replace function getchar(pesel char(11), i integer) returns integer as $$
begin
  return cast(substr(pesel, i, 1) as integer);
end;
$$ language plpgsql;;

create or replace function pesel_check() returns trigger as
$$
begin
	if (1 * getchar(new.pesel, 1) + 3 * getchar(new.pesel, 2) + 7 * getchar(new.pesel, 3) + 9 * getchar(new.pesel, 4) + 1 * getchar(new.pesel, 5) + 3 * getchar(new.pesel, 6) + 7 * getchar(new.pesel, 7) + 9 * getchar(new.pesel, 8) + 1 * getchar(new.pesel, 9) + 3 * getchar(new.pesel, 10) + getchar(new.pesel, 11)) % 10 = 0 then
    return new;
  else
    return null;
  end if;
end;
$$ language plpgsql;;

create or replace function recepty_check() returns trigger as $$
declare 
    x numeric; -- := nextval('"dkm-healthcare".seq_nr_recepty');
begin
		x = new.numer;
		if x is null then x = nextval('"dkm-healthcare".seq_nr_recepty');
		end if;
    while x in (select numer from "dkm-healthcare".recepty) loop
        x = nextval('"dkm-healthcare".seq_nr_recepty');
    end loop;
    new.numer=x;
    return new;
end;
$$ language plpgsql;;

create or replace function skier_check() returns trigger as $$
declare 
    x numeric; -- := nextval('"dkm-healthcare".seq_nr_skier');
begin
		x = new.numer;
		if x is null then x = nextval('"dkm-healthcare".seq_nr_skier');
		end if;
    while x in (select numer from "dkm-healthcare".skierowania) loop
        x = nextval('"dkm-healthcare".seq_nr_skier');
    end loop;
    new.numer=x;
    return new;
end;
$$ language plpgsql;;

create or replace function zabiegi_check() returns trigger as $$
declare 
    x numeric; -- := nextval('"dkm-healthcare".seq_id_zabieg');
begin
		x = new.id_zabieg;
		if x is null then x = nextval('"dkm-healthcare".seq_id_zabieg');
		end if;
    while x in (select id_zabieg from "dkm-healthcare".zabiegi) loop
        x = nextval('"dkm-healthcare".seq_id_zabieg');
    end loop;
    new.id_zabieg=x;
    return new;
end;
$$ language plpgsql;;



create trigger add_osoba_info after insert on "dkm-healthcare".osoby for row
execute procedure add_osoba_info();;

create trigger change_pesel_check before update on "dkm-healthcare".osoby for row
execute procedure change_pesel_check();;

create trigger pesel_check before insert on "dkm-healthcare".osoby
for each row execute procedure pesel_check();;

create trigger recepty_check before insert on "dkm-healthcare".recepty for row
execute procedure recepty_check();;

create trigger skier_check before insert on "dkm-healthcare".skierowania for row
execute procedure skier_check();;

create trigger zabieg_check before insert on "dkm-healthcare".zabiegi for row
execute procedure zabiegi_check();;


-- INSERTS

--OSOBY
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('64050701526',md5('rozniczka'),'michal','swietek',date'1988-05-15','gutenberga 4, krakow', false, 'michal.swietek@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('46101807072',md5('konszfkapralka'),'kamil','jarosz',date'1992-11-19','lojasiewicza 4, krakow', false, 'kjarosz@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('35052119448',md5(''),'dudu','',date'1988-05-15','gutenberga 4, krakow', false, 'dudu@dudu.tcs');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('20091508269',md5('calka'),'leonard','euler',date'1986-04-25','gdzie 88, warszawa', true, 'leuler@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('62080713094',md5('pochodna'),'stefan','banach',date'1989-05-15','krakowska 45, krakow', false, 'sbanach@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('91072415658',md5('styczna'),'stanislaw','mazur',date'1388-05-15','lwowska 24, katowice', false, 'smazur@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('05270102489',md5('homologie'),'henry','poincare',date'1968-05-25','warszawska 2, paryz', false, 'hpoincare@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('50090903529',md5('homokliniczny'),'lew','tolstoj',date'1888-11-11','paryska 4, warszawa', false, 'ltolstoj@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('14082319730',md5('raskolnikow'),'michal','dostojewski',date'1788-01-15','katowicka 13, petersburg', false, null);
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('07220302192',md5('podwiazka'),'bernard','riemann',date'1868-12-21','mila 77, berlin', false, 'hpoincare@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('48021514432',md5('ulises'),'james','joyce',date'1921-03-20','dublinska 411, dublin', false, 'ltolstoj@uj.edu.pl');
insert into "dkm-healthcare".osoby(pesel,haslo,imie,nazwisko,data_urodzenia,adres,aptekarz,email) values ('50012913591',md5('badumbum'),'tim','gowers',date'1911-01-01','londynska 34, londyn', false, null);


--PLACOWKI
insert into "dkm-healthcare".placowki values (1,'poradnia', 'poradnia wniebowstapienia','diabelna 13', 'radom', 7777777);
insert into "dkm-healthcare".placowki values (2,'poradnia', 'poradnia lezenia','szu 3', 'wola', 999);
insert into "dkm-healthcare".placowki values (3,'szpital', 'szpital dzieciecy','smierci 12', 'gdynia', 998);
insert into "dkm-healthcare".placowki values (4,'szpital', 'szpital mlodziezy','agoni 22', 'warszawa', 123321);
insert into "dkm-healthcare".placowki values (5,'przychodnia', 'przychodnia zamknieta','oplaty 99', 'sosnowiec', 997);
insert into "dkm-healthcare".placowki values (6,'przychodnia', 'przychodnia mocy','jadi 0', 'poznan', 992);


--SPECJALIZACJE
insert into "dkm-healthcare".specjalizacje values ('urolog',1);
insert into "dkm-healthcare".specjalizacje values ('anestezjolog',2);
insert into "dkm-healthcare".specjalizacje values ('ortopeda',3);
insert into "dkm-healthcare".specjalizacje values ('pediatra',4);
insert into "dkm-healthcare".specjalizacje values ('radiolog',5);
insert into "dkm-healthcare".specjalizacje values ('naurolog',6);
insert into "dkm-healthcare".specjalizacje values ('chirurg',7);
insert into "dkm-healthcare".specjalizacje values ('kardiolog',8);
insert into "dkm-healthcare".specjalizacje values ('ginekolog',9);
insert into "dkm-healthcare".specjalizacje values ('dentysta',10);


--ZABIEGI
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja lewej nogi');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja prawej nogi');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja lewej dloni');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja prawej dloni');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja prawego przedramienia');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja lewego przedramienia');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja prawej reki');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja lewej reki');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja glowy');
insert into "dkm-healthcare".zabiegi(nazwa) values ('amputacja lewego malego palca stopy');


--LEKARZE
insert into "dkm-healthcare".lekarze values ('50012913591',true);
insert into "dkm-healthcare".lekarze values ('48021514432',true);
insert into "dkm-healthcare".lekarze values ('07220302192',true);
insert into "dkm-healthcare".lekarze values ('14082319730',false);


--OSOBY_INFO
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='50012913591' where pesel='64050701526';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='07220302192' where pesel='46101807072';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='07220302192' where pesel='35052119448';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='50012913591' where pesel='20091508269';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='07220302192' where pesel='62080713094';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='48021514432' where pesel='91072415658';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='48021514432', info='nie ma nerki' where pesel='05270102489';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='48021514432', info='ma 3 nogi' where pesel='50090903529';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='48021514432' where pesel='50090903529';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='50012913591' where pesel='07220302192';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='50012913591', info='obojnak' where pesel='48021514432';
update "dkm-healthcare".osoby_info set  lekarz_rodzinny='07220302192' where pesel='50012913591';

--OSOBY_ALERGIE
insert into "dkm-healthcare".osoby_alergie values ('64050701526', 'brzydkie_dowody');
insert into "dkm-healthcare".osoby_alergie values ('35052119448', 'szczypka');
insert into "dkm-healthcare".osoby_alergie values ('35052119448', 'slonce');
insert into "dkm-healthcare".osoby_alergie values ('05270102489', 'anglicy');

--OSOBY_LEKI
insert into "dkm-healthcare".osoby_leki values ('91072415658', 'cukier');
insert into "dkm-healthcare".osoby_leki values ('35052119448', 'herbata z cytryna, raz dziennie');
insert into "dkm-healthcare".osoby_leki values ('46101807072', 'viagra');
insert into "dkm-healthcare".osoby_leki values ('46101807072', 'jogurt');
insert into "dkm-healthcare".osoby_leki values ('48021514432', 'rutinoscorbin, 3x dziennie');

--PACJENCI_SPECJALISCI
insert into "dkm-healthcare".pacjenci_specjalisci values ('64050701526', '48021514432');
insert into "dkm-healthcare".pacjenci_specjalisci values ('64050701526', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('46101807072', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('46101807072', '50012913591');
insert into "dkm-healthcare".pacjenci_specjalisci values ('35052119448', '50012913591');
insert into "dkm-healthcare".pacjenci_specjalisci values ('20091508269', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('62080713094', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('62080713094', '48021514432');
insert into "dkm-healthcare".pacjenci_specjalisci values ('91072415658', '48021514432');
insert into "dkm-healthcare".pacjenci_specjalisci values ('91072415658', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('91072415658', '50012913591');
insert into "dkm-healthcare".pacjenci_specjalisci values ('50090903529', '48021514432');
insert into "dkm-healthcare".pacjenci_specjalisci values ('50090903529', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('14082319730', '48021514432');
insert into "dkm-healthcare".pacjenci_specjalisci values ('14082319730', '07220302192');
insert into "dkm-healthcare".pacjenci_specjalisci values ('07220302192', '50012913591');
insert into "dkm-healthcare".pacjenci_specjalisci values ('07220302192', '48021514432');
insert into "dkm-healthcare".pacjenci_specjalisci values ('48021514432', '50012913591');
insert into "dkm-healthcare".pacjenci_specjalisci values ('48021514432', '07220302192');


--PLACOWKI_ZABIEGI
insert into "dkm-healthcare".placowki_zabiegi values ( 1, 1);
insert into "dkm-healthcare".placowki_zabiegi values ( 1, 2);
insert into "dkm-healthcare".placowki_zabiegi values ( 1, 3);
insert into "dkm-healthcare".placowki_zabiegi values ( 2, 4);
insert into "dkm-healthcare".placowki_zabiegi values ( 2, 6);
insert into "dkm-healthcare".placowki_zabiegi values ( 2, 7);
insert into "dkm-healthcare".placowki_zabiegi values ( 2, 9);
insert into "dkm-healthcare".placowki_zabiegi values ( 3, 2);
insert into "dkm-healthcare".placowki_zabiegi values ( 3, 3);
insert into "dkm-healthcare".placowki_zabiegi values ( 3, 5);
insert into "dkm-healthcare".placowki_zabiegi values ( 3, 7);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 1);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 3);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 5);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 7);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 9);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 2);
insert into "dkm-healthcare".placowki_zabiegi values ( 4, 4);
insert into "dkm-healthcare".placowki_zabiegi values ( 5, 10);
insert into "dkm-healthcare".placowki_zabiegi values ( 6, 10);


--RECEPTY

insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('64050701526', '48021514432', 'czekolada 3x dziennie');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('64050701526', '07220302192', 'czopki');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('46101807072', '07220302192', 'gardlox');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('46101807072', '50012913591', 'ciastka codziennie po 3');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('35052119448', '50012913591', 'jabblko z gruszka');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('20091508269', '07220302192', 'gripex');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('62080713094', '07220302192', 'krople wody 8 razy na godzinę');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('62080713094', '48021514432', 'apap');
insert into "dkm-healthcare".recepty(pesel, id_lekarz, lek) values ('91072415658', '48021514432', 'apap');


--SKIEROWANIA

insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('62080713094', '07220302192', 1);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('62080713094', '48021514432', 1);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('91072415658', '48021514432', 2);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('91072415658', '07220302192', 1);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('91072415658', '50012913591', 3);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('50090903529', '48021514432', 2);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('50090903529', '07220302192', 1);
insert into "dkm-healthcare".skierowania(pesel, id_lekarz, id_zabieg) values ('14082319730', '48021514432', 3);


--LEKARZE_PLACOWKI
insert into "dkm-healthcare".lekarze_placowki values ('07220302192', 1);
insert into "dkm-healthcare".lekarze_placowki values ('07220302192', 2);
insert into "dkm-healthcare".lekarze_placowki values ('07220302192', 4);
insert into "dkm-healthcare".lekarze_placowki values ('07220302192', 6);
insert into "dkm-healthcare".lekarze_placowki values ('50012913591', 3);
insert into "dkm-healthcare".lekarze_placowki values ('50012913591', 1);
insert into "dkm-healthcare".lekarze_placowki values ('50012913591', 5);
insert into "dkm-healthcare".lekarze_placowki values ('50012913591', 6);
insert into "dkm-healthcare".lekarze_placowki values ('48021514432', 5);
insert into "dkm-healthcare".lekarze_placowki values ('48021514432', 1);
insert into "dkm-healthcare".lekarze_placowki values ('48021514432', 2);
insert into "dkm-healthcare".lekarze_placowki values ('48021514432', 3);


--LEKARZE_SPECJALIZACJE
insert into "dkm-healthcare".lekarze_specjalizacje values ('07220302192', 1);
insert into "dkm-healthcare".lekarze_specjalizacje values ('07220302192', 2);
insert into "dkm-healthcare".lekarze_specjalizacje values ('50012913591', 3);
insert into "dkm-healthcare".lekarze_specjalizacje values ('50012913591', 4);
insert into "dkm-healthcare".lekarze_specjalizacje values ('50012913591', 5);
insert into "dkm-healthcare".lekarze_specjalizacje values ('48021514432', 6);
insert into "dkm-healthcare".lekarze_specjalizacje values ('48021514432', 7);
insert into "dkm-healthcare".lekarze_specjalizacje values ('48021514432', 8);
insert into "dkm-healthcare".lekarze_specjalizacje values ('48021514432', 9);
insert into "dkm-healthcare".lekarze_specjalizacje values ('48021514432', 10);



