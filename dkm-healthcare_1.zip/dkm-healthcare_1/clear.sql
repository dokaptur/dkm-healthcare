drop schema "dkm-healthcare" cascade;
